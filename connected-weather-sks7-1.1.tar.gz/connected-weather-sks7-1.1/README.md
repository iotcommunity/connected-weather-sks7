# connected-weather-sks7
